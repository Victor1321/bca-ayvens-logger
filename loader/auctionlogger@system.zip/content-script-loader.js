(function () {
  console.log("[SYSTEM ADDON] Loader starting…");

  const CLIENT = "bogdan"; //
  const BASE = "https://bca-ayvens-logger.fly.dev/public/";

  const HOST = location.hostname;

  const ALLOWED_HOSTS = [
    // BCA
    "www.bca.com",
    "bca.com",
    "login.bca.com",
    "ee.bca-europe.com",
    "idp.bca-online-auctions.eu",
    // Ayvens
    "carmarket.ayvens.com",
  ];

  if (!ALLOWED_HOSTS.includes(HOST)) {
    return;
  }

  console.log("[SYSTEM ADDON] Loader running on", HOST);

  const scripts = [
    `logger-script-${CLIENT}.js`, // logger per angajat
    `autologin-bca.js`, // comun BCA
    `autologin-ayvens.js`, // comun Ayvens
  ];

  function inject(url) {
    try {
      const s = document.createElement("script");
      s.src = url + "?v=" + Date.now(); // cache-buster
      s.type = "text/javascript";
      s.async = false;
      (document.head || document.documentElement).appendChild(s);
      console.log("[SYSTEM ADDON] Injected:", url);
    } catch (e) {
      console.error("[SYSTEM ADDON] Failed to inject:", url, e);
    }
  }

  scripts.forEach((file) => inject(BASE + file));

  // -------------------------------------------------
  // BRIDGE: page script <-> extensie pentru credențiale
  // -------------------------------------------------
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    const data = event.data || {};

    // BCA
    if (data.type === "BCA_GET_CREDS") {
      console.log(
        "[SYSTEM ADDON] Primit cerere credențiale BCA de la pagină..."
      );

      try {
        const res = await fetch(
          "https://bca-ayvens-logger.fly.dev/auto-login-bca",
          {
            method: "POST",
          }
        );
        const json = await res.json();

        window.postMessage(
          {
            type: "BCA_CREDS",
            creds: json,
          },
          "*"
        );

        console.log(
          "[SYSTEM ADDON] Am trimis credențiale BCA înapoi către pagină"
        );
      } catch (e) {
        console.error("[SYSTEM ADDON] Eroare la fetch credențiale BCA:", e);
        window.postMessage(
          {
            type: "BCA_CREDS",
            creds: null,
          },
          "*"
        );
      }
    }

    // AYVENS
    if (data.type === "AYVENS_GET_CREDS") {
      console.log(
        "[SYSTEM ADDON] Primit cerere credențiale AYVENS de la pagină..."
      );

      try {
        const res = await fetch(
          "https://bca-ayvens-logger.fly.dev/auto-login-ayvens",
          {
            method: "POST",
          }
        );
        const json = await res.json();

        window.postMessage(
          {
            type: "AYVENS_CREDS",
            creds: json,
          },
          "*"
        );

        console.log(
          "[SYSTEM ADDON] Am trimis credențiale AYVENS înapoi către pagină"
        );
      } catch (e) {
        console.error("[SYSTEM ADDON] Eroare la fetch credențiale AYVENS:", e);
        window.postMessage(
          {
            type: "AYVENS_CREDS",
            creds: null,
          },
          "*"
        );
      }
    }
  });
})();
